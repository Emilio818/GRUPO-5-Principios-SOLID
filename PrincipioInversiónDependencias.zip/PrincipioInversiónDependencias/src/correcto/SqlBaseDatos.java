
package correcto;

/**
 *
 * @author emifu
 */
public class SqlBaseDatos implements Persistencia {

    @Override
    public void guardar(Compra compra) {
        // Se guardara en un SQL...
    }
    
}
