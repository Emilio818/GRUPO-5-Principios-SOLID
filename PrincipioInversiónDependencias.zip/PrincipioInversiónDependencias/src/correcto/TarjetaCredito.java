
package correcto;


/**
 *
 * @author emifu
 */
public class TarjetaCredito implements MetodoDePago {

    @Override
    public void pagar(Compra compra) {
        // Se paga por TarjetaCredito...
    }
    
}
