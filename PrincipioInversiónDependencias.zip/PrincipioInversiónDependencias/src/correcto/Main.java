/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package correcto;



/**
 *
 * @author emifu
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Se instancia fuera de las clases
        Compra compra = new Compra();
        SqlBaseDatos sqlBaseDatos = new SqlBaseDatos();
        TarjetaCredito tarjetaCredito = new TarjetaCredito();
        
        Server server = new Server();
        Paypal paypal = new Paypal();
        
        // Las dependencias se suministrar por medio de Constructores
        CestaCompras cestaCompras1 = new CestaCompras(sqlBaseDatos, tarjetaCredito);
        cestaCompras1.comprar(compra);
        
        CestaCompras cestaCompras2 = new CestaCompras(server, paypal);
        cestaCompras2.comprar(compra);
    }
    
}
