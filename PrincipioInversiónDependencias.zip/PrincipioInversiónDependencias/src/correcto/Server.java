
package correcto;


/**
 *
 * @author emifu
 */
public class Server implements Persistencia {

    @Override
    public void guardar(Compra compra) {
        // Los datos se guardan en un server...
    }
    
}
