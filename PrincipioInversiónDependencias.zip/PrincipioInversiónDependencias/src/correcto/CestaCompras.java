
package correcto;

/**
 *
 * @author emifu
 */
public class CestaCompras {
    private Persistencia persistencia;
    private MetodoDePago metodoDePago;
    public CestaCompras(Persistencia persistencia, MetodoDePago metodoDePago){
        this.persistencia = persistencia;
        this.metodoDePago = metodoDePago;
    }
    
    public void comprar(Compra compra) {
        persistencia.guardar(compra);
        metodoDePago.pagar(compra);
    }
}
