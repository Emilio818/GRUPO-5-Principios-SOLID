
package correcto;


/**
 *
 * @author emifu
 */
public class Paypal implements MetodoDePago {

    @Override
    public void pagar(Compra compra) {
        // Se paga por medio de PayPal...
    }
    
}
