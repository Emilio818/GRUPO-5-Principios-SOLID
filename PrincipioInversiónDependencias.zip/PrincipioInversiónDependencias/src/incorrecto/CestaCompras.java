
package incorrecto;

/**
 *
 * @author emifu
 */
public class CestaCompras { 
    public void comprar(Compra compra) {
        SqlBaseDatos bd = new SqlBaseDatos();
        bd.guardar(compra);
        TarjetaCredito tarjetaCredito = new TarjetaCredito();
        tarjetaCredito.pagar(compra);
    }
}
