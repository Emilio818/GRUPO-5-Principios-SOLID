
package incorrecto;

/**
 *
 * @author emifu
 */
public class SqlBaseDatos {
    public void guardar(Compra compra) {
        // Guarda en base de datos Sql...
    }
}
