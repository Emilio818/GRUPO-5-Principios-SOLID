
package incorrecto;

/**
 *
 * @author emifu
 */
public class TarjetaCredito {
    public void pagar(Compra compra) {
        // Metodo de pago Tarjeta de Credito...
    }
}
