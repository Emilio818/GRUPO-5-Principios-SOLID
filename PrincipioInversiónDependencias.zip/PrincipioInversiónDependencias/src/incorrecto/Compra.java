
package incorrecto;

/**
 *
 * @author emifu
 */
public class Compra {
    // Lista de objetos a comprar
}
